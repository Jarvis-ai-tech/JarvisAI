from flask import Flask, render_template, redirect, url_for
import stripe

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

stripe.api_key = 'your_stripe_secret_key_here'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/pay')
def pay():
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price_data': {
                'currency': 'usd',
                'product_data': {'name': 'Jarvis AI Access'},
                'unit_amount': 500,
            },
            'quantity': 1,
        }],
        mode='payment',
        success_url=url_for('success', _external=True),
        cancel_url=url_for('index', _external=True),
    )
    return redirect(session.url, code=303)

@app.route('/success')
def success():
    return render_template('success.html')

@app.route('/jarvis')
def jarvis():
    return render_template('ai.html')

if __name__ == '__main__':
    app.run(debug=True)