# Secure JarvisAI Flask app with env-based secrets (example)
from flask import Flask, redirect, url_for, session, request, render_template
import os

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "your-default-secret")

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/login')
def login():
    return render_template("login.html")

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)
